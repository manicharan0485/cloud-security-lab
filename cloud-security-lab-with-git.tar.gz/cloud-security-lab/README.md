# cloud-security-lab

A small, deliberately minimal reference project showing how **Terraform →
Kubernetes → Docker** fit together as layers, with the security reasoning at
each layer commented inline. Built as interview-prep for a Cloud Security
Engineer role — the goal is to be able to point at real files and explain
*why* each choice exists, not to memorize a script.

## Layers

```
terraform/   → provisions the infrastructure everything else runs on:
               VPC (private subnets for nodes, public only for NAT/LB),
               EKS cluster + managed node group, least-privilege IAM roles,
               KMS-encrypted secrets at rest, control-plane audit logging.

k8s/         → runs Docker containers on top of that infrastructure:
               namespace.yaml   - isolation boundary
               rbac.yaml        - who/what can call the K8s API, and for what
               network-policy.yaml - default-deny pod-to-pod traffic, then
                                     explicit allow rules only where needed
               deployment.yaml  - the actual workload, with pod/container
                                  securityContext hardening
               secret.example.yaml - template only, never commit real values

app/         → the actual application (deliberately trivial) plus the
               Dockerfile that packages it: pinned base image, non-root user,
               multi-stage-ready structure, .dockerignore to avoid leaking
               local files into the image.
```

## How to talk about this in an interview

- **Docker** = packaging/workload layer. Security concerns: image
  provenance/scanning, non-root user, minimal base image.
- **Kubernetes** = orchestration layer. Security concerns: RBAC (API access
  control) and NetworkPolicy (pod-to-pod traffic control) are *separate*
  mechanisms protecting *different* attack surfaces — a compromised pod with
  no RBAC permissions can still reach other pods over the network unless a
  NetworkPolicy stops it, and vice versa.
- **Terraform** = infrastructure layer, below Kubernetes. Security concerns:
  least-privilege IAM for the cluster/nodes, private subnets so nodes have no
  direct inbound path from the internet, encryption (KMS) for secrets at
  rest, and audit logging so you can answer "who did what" later.

## Explicitly NOT included

- No CI/CD pipeline wiring in this repo yet (add a GitHub Actions or GitLab
  CI workflow that runs `terraform plan`, a container scan, and `kubeval`/
  `kube-linter` against the manifests, if you want to extend this).
- No actual secret values anywhere — `secret.example.yaml` is a template.
- Not production-hardened end to end (e.g. the EKS public endpoint CIDR is a
  placeholder) — it's a study reference, say so if asked.

## Local sanity checks (no cloud account required)

```bash
# Lint the Dockerfile
docker build -t cloud-security-lab-app ./app

# Validate Terraform syntax without touching real AWS resources
cd terraform && terraform init -backend=false && terraform validate

# Validate Kubernetes manifest syntax
kubectl apply --dry-run=client -f k8s/
```
